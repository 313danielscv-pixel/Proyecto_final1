import pandas as pd

from src.business_intelligence import compare_scenario, inventory_intelligence
from src.contracts import INVENTORY_CONTRACT, SALES_CONTRACT
from src.ingestion import parse_csv


def test_sales_aliases_are_mapped_and_parsed() -> None:
    data, report = parse_csv(b"fecha,sku,unidades\n2026-01-01,SKU-1,4\n", SALES_CONTRACT)

    assert set(data.columns) == {"date", "product_id", "quantity"}
    assert report.missing_required == ()
    assert report.valid_rows == 1


def test_invalid_numeric_values_are_reported() -> None:
    _, report = parse_csv(b"fecha,sku,unidades\n2026-01-01,SKU-1,-4\n", SALES_CONTRACT)

    assert report.invalid_values["quantity"] == 1
    assert report.valid_rows == 0


def test_inventory_risk_uses_observed_stock_and_demand() -> None:
    inventory = pd.DataFrame(
        {"product_id": ["SKU-1", "SKU-2"], "on_hand_units": [4, 500], "reorder_lead_days": [5, 2]}
    )
    demand = pd.DataFrame({"product_id": ["SKU-1", "SKU-2"], "quantity": [2.0, 5.0]})

    result = inventory_intelligence(inventory, demand)

    assert result.loc[0, "risk"] == "rotura"
    assert result.loc[1, "risk"] == "sobrestock"


def test_scenario_result_distinguishes_estimated_margin_change() -> None:
    scenario = compare_scenario(10, 10, 4, 0.1, 2, -10, 20)

    assert scenario.revenue == 108
    assert round(scenario.margin_change, 2) == -0.40
