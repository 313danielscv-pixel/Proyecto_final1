"""Build a transparent demonstration bundle from real demand and scenario assumptions."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from src.data_pipeline import ROOT
from src.real_demand import TRAIN_PATH


DEMO_DIRECTORY = ROOT / "data" / "demo"
DEMO_METADATA = DEMO_DIRECTORY / "README_DEMO.json"


def build_demo_bundle() -> dict[str, Path]:
    """Create company-shaped demo CSVs from one real store-product demand series."""
    columns = ["store_id", "product_id", "dt", "sale_amount", "discount", "holiday_flag"]
    train = pd.read_parquet(TRAIN_PATH, columns=columns)
    first_series = train[["store_id", "product_id"]].drop_duplicates().sort_values(["store_id", "product_id"]).iloc[0]
    series = train.loc[
        (train["store_id"] == first_series["store_id"]) & (train["product_id"] == first_series["product_id"])
    ].copy()
    series["dt"] = pd.to_datetime(series["dt"])
    series = series.sort_values("dt")
    product_id = f"FRN-{int(first_series['product_id'])}"
    store_id = f"FRN-STORE-{int(first_series['store_id'])}"
    DEMO_DIRECTORY.mkdir(parents=True, exist_ok=True)

    sales = pd.DataFrame(
        {
            "date": series["dt"].dt.date.astype(str),
            "product_id": product_id,
            "quantity": series["sale_amount"],
            "store_id": store_id,
            "category": "fresh_retail_demo",
            "promotion": series["discount"].lt(1),
        }
    )
    average_demand = float(sales["quantity"].mean())
    inventory = pd.DataFrame(
        {
            "snapshot_date": [sales["date"].iloc[-1]],
            "product_id": [product_id],
            "on_hand_units": [max(round(average_demand * 18, 2), 1)],
            "unit_cost": [2.40],
            "reorder_lead_days": [5],
            "minimum_stock": [max(round(average_demand * 5, 2), 1)],
            "store_id": [store_id],
            "expiry_date": [""],
        }
    )
    costs = pd.DataFrame(
        {
            "effective_date": [sales["date"].iloc[-1]],
            "product_id": [product_id],
            "unit_cost": [2.40],
            "unit_price": [4.80],
            "holding_cost_per_unit_day": [0.03],
        }
    )
    latest_date = pd.to_datetime(sales["date"].iloc[-1])
    lots = pd.DataFrame(
        {
            "lot_id": ["FRN-DEMO-LOT-001"],
            "product_id": [product_id],
            "stock_available": [max(round(average_demand * 10, 2), 1)],
            "expiry_date": [(latest_date + pd.Timedelta(days=4)).date().isoformat()],
            "unit_cost": [2.40],
            "store_id": [store_id],
        }
    )
    paths = {
        "sales": DEMO_DIRECTORY / "ventas_demanda_real_demo.csv",
        "inventory": DEMO_DIRECTORY / "inventario_escenario_demo.csv",
        "costs": DEMO_DIRECTORY / "costes_escenario_demo.csv",
        "lots": DEMO_DIRECTORY / "lotes_escenario_demo.csv",
    }
    sales.to_csv(paths["sales"], index=False)
    inventory.to_csv(paths["inventory"], index=False)
    costs.to_csv(paths["costs"], index=False)
    lots.to_csv(paths["lots"], index=False)
    DEMO_METADATA.write_text(
        json.dumps(
            {
                "real_source": "FreshRetailNet-50K by Dingdong Inc., CC BY 4.0",
                "source_url": "https://huggingface.co/datasets/Dingdong-Inc/FreshRetailNet-50K",
                "real_fields": ["date", "product_id", "quantity", "store_id", "promotion"],
                "scenario_fields": {
                    "inventory": "Stock, lead time and safety stock are demonstration assumptions.",
                    "costs": "Unit cost, price and holding cost are demonstration assumptions.",
                    "lots": "Lot stock and expiry date are demonstration assumptions.",
                },
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return paths


if __name__ == "__main__":
    print({name: str(path) for name, path in build_demo_bundle().items()})
