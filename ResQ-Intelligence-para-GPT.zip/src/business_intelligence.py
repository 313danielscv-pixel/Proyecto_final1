"""Reusable demand, inventory, profitability and scenario calculations."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


@dataclass(frozen=True)
class ScenarioResult:
    """A transparent economic scenario; values are estimates, never realised savings."""

    revenue: float
    product_cost: float
    holding_cost: float
    gross_margin: float
    margin_change: float


def sales_eda(sales: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """Build summaries only from columns available in the uploaded sales contract."""
    daily = sales.groupby("date", as_index=False)["quantity"].sum().sort_values("date")
    product = sales.groupby("product_id", as_index=False)["quantity"].sum().sort_values("quantity", ascending=False)
    result = {"daily_demand": daily, "products": product}
    if "unit_price" in sales:
        enriched = sales.assign(revenue=sales["quantity"] * sales["unit_price"])
        result["revenue_by_product"] = (
            enriched.groupby("product_id", as_index=False)["revenue"].sum().sort_values("revenue", ascending=False)
        )
    return result


def inventory_intelligence(inventory: pd.DataFrame, daily_demand: pd.DataFrame) -> pd.DataFrame:
    """Calculate coverage and stock risks from observed stock and average daily demand."""
    demand = daily_demand.rename(columns={"quantity": "daily_demand"})
    result = inventory.merge(demand, on="product_id", how="left")
    result["daily_demand"] = result["daily_demand"].fillna(0)
    result["coverage_days"] = result["on_hand_units"] / result["daily_demand"].replace(0, pd.NA)
    result["capital_exposed"] = result["on_hand_units"] * result.get("unit_cost", 0)
    if "unit_price" in result and "unit_cost" in result:
        result["unit_margin"] = result["unit_price"] - result["unit_cost"]
    lead_time = result.get("reorder_lead_days", pd.Series(0, index=result.index)).fillna(0)
    minimum_stock = result.get("minimum_stock", pd.Series(0, index=result.index)).fillna(0)
    result["risk"] = "equilibrado"
    result.loc[(result["coverage_days"].fillna(float("inf")) < lead_time) | (result["on_hand_units"] < minimum_stock), "risk"] = "rotura"
    result.loc[result["coverage_days"].fillna(0) > 45, "risk"] = "sobrestock"
    return result


def compare_scenario(
    baseline_units: float,
    baseline_price: float,
    unit_cost: float,
    holding_cost_per_unit_day: float,
    days_held: float,
    price_change_pct: float,
    demand_change_pct: float,
) -> ScenarioResult:
    """Compare a price and demand assumption with the current operating baseline."""
    scenario_units = baseline_units * (1 + demand_change_pct / 100)
    scenario_price = baseline_price * (1 + price_change_pct / 100)
    revenue = scenario_units * scenario_price
    product_cost = scenario_units * unit_cost
    holding_cost = scenario_units * holding_cost_per_unit_day * days_held
    gross_margin = revenue - product_cost - holding_cost
    baseline_margin = baseline_units * baseline_price - baseline_units * unit_cost - (
        baseline_units * holding_cost_per_unit_day * days_held
    )
    return ScenarioResult(revenue, product_cost, holding_cost, gross_margin, gross_margin - baseline_margin)
