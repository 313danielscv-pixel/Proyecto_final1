"""Streamlit views for the reusable ResQ Intelligence platform."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

from src.business_intelligence import compare_scenario, inventory_intelligence, sales_eda
from src.advanced_eda import (
    bootstrap_mean_interval,
    correlation_matrix,
    group_difference,
    numeric_summary,
    population_stability_index,
    profile_data,
    quality_summary,
    segment_rows,
    temporal_summary,
)
from src.contracts import DATASET_CONTRACTS, COSTS_CONTRACT, INVENTORY_CONTRACT, LOTS_CONTRACT, SALES_CONTRACT
from src.demo_data import DEMO_DIRECTORY
from src.ingestion import parse_tabular
from src.lot_risk import build_lot_risk
from src.real_demand import FORECAST_PATH, METRICS_PATH, SOURCE_URL


def render_uploads() -> None:
    """Let an organisation upload independent CSVs and inspect their quality."""
    st.subheader("Carga y calidad de datos")
    st.write("Carga solo los archivos que tengas. Cada módulo se habilita cuando existen los campos necesarios.")
    if st.button("Cargar demostración con demanda real", type="primary"):
        demo_files = {
            "sales": DEMO_DIRECTORY / "ventas_demanda_real_demo.csv",
            "inventory": DEMO_DIRECTORY / "inventario_escenario_demo.csv",
            "costs": DEMO_DIRECTORY / "costes_escenario_demo.csv",
            "lots": DEMO_DIRECTORY / "lotes_escenario_demo.csv",
        }
        if not all(path.exists() for path in demo_files.values()):
            st.error("Faltan los archivos de demostración. Ejecuta `python -m src.demo_data`.")
        else:
            st.session_state["business_data"] = {
                dataset_key: pd.read_csv(path) for dataset_key, path in demo_files.items()
            }
            st.session_state["demo_loaded"] = True
            st.success("Demostración cargada. Revisa EDA empresarial, Inventario y margen y Riesgo por lote.")
    if st.session_state.get("demo_loaded"):
        st.info(
            "Demostración activa: ventas reales de FreshRetailNet-50K. Inventario, costes y lote son "
            "supuestos de escenario claramente identificados, no datos observados de la fuente."
        )
    loaded: dict[str, pd.DataFrame] = dict(_business_data())
    for contract in DATASET_CONTRACTS:
        upload = st.file_uploader(
            f"{contract.title}: {contract.filename}",
            type=["csv", "xlsx"],
            help=contract.purpose,
            key=f"upload_{contract.key}",
        )
        if upload is None:
            continue
        data, report = parse_tabular(upload.getvalue(), upload.name, contract)
        loaded[contract.key] = data
        st.session_state["demo_loaded"] = False
        if report.missing_required:
            st.error(f"{contract.title}: faltan campos obligatorios: {', '.join(report.missing_required)}.")
        else:
            st.success(f"{contract.title}: {report.valid_rows}/{report.total_rows} filas aptas para su módulo principal.")
        if report.invalid_values:
            st.warning(f"Valores no válidos o negativos: {report.invalid_values}.")
        if report.duplicate_rows:
            st.warning(f"Filas duplicadas detectadas: {report.duplicate_rows}. No se han eliminado automáticamente.")
        st.caption(f"Mapeo detectado: {report.mapped_columns}")
        st.dataframe(data.head(20), use_container_width=True, hide_index=True)
    if loaded:
        st.session_state["business_data"] = loaded
        st.info("Los datos cargados permanecen solo en esta sesión del navegador; no se guardan en el repositorio.")


def _business_data() -> dict[str, pd.DataFrame]:
    return st.session_state.get("business_data", {})


def render_business_eda() -> None:
    """Render EDA only when a valid sales upload is available."""
    st.subheader("Análisis exploratorio empresarial")
    sales = _business_data().get(SALES_CONTRACT.key)
    if sales is None or not {"date", "product_id", "quantity"}.issubset(sales.columns):
        st.info("Carga un archivo de ventas válido en la pestaña Carga y calidad para activar este análisis.")
        return
    results = sales_eda(sales.dropna(subset=["date", "product_id", "quantity"]))
    total_units = results["daily_demand"]["quantity"].sum()
    st.metric("Unidades vendidas analizadas", f"{total_units:,.0f}")
    left, right = st.columns(2)
    with left:
        st.plotly_chart(
            px.line(results["daily_demand"], x="date", y="quantity", title="Demanda diaria observada"),
            use_container_width=True,
        )
    with right:
        st.plotly_chart(
            px.bar(results["products"].head(15), x="product_id", y="quantity", title="Productos con mayor volumen"),
            use_container_width=True,
        )
    if "revenue_by_product" in results:
        st.plotly_chart(
            px.bar(
                results["revenue_by_product"].head(15),
                x="product_id",
                y="revenue",
                title="Facturación estimada por producto",
            ),
            use_container_width=True,
        )


def render_advanced_eda() -> None:
    """Render a generic EDA workbench for any currently loaded business dataset."""
    st.subheader("EDA avanzado y calidad")
    data_sets = _business_data()
    if not data_sets:
        st.info("Carga un CSV o Excel para activar el EDA avanzado.")
        return
    selected_key = st.selectbox("Conjunto de datos", sorted(data_sets), format_func=lambda key: key.capitalize())
    data = data_sets[selected_key].copy()
    numeric_columns = data.select_dtypes(include="number").columns.tolist()
    categorical_columns = [column for column in data.columns if column not in numeric_columns]
    profile_tab, univariate_tab, relations_tab, time_tab, robustness_tab = st.tabs(
        ["Perfil y calidad", "Distribuciones", "Relaciones", "Tiempo y anomalías", "Robustez"]
    )
    with profile_tab:
        report = quality_summary(data)
        first, second, third, fourth = st.columns(4)
        first.metric("Filas", report["rows"])
        second.metric("Columnas", report["columns"])
        third.metric("Celdas nulas", report["missing_cells"])
        fourth.metric("Filas duplicadas", report["duplicate_rows"])
        if report["negative_values"]:
            st.warning(f"Valores negativos detectados: {report['negative_values']}. Revísalos según las reglas de negocio.")
        if report["potential_leakage_columns"]:
            st.warning(
                "Posible fuga de información por nombre de columna: "
                f"{report['potential_leakage_columns']}. Si se entrena un modelo, confirma que estas variables "
                "no contengan un resultado conocido después de la decisión."
            )
        st.caption("No hay un modelo predictivo compatible cargado: SHAP/LIME no se aplican en este EDA.")
        st.dataframe(
            profile_data(data).style.format({"porcentaje_nulo": "{:.1%}"}),
            use_container_width=True,
            hide_index=True,
        )
        st.download_button(
            "Descargar perfil CSV",
            profile_data(data).to_csv(index=False).encode("utf-8"),
            file_name=f"perfil_{selected_key}.csv",
            mime="text/csv",
        )
    with univariate_tab:
        if not numeric_columns:
            st.info("Este conjunto no contiene columnas numéricas analizables.")
        else:
            column = st.selectbox("Variable numérica", numeric_columns, key="univariate_column")
            st.dataframe(numeric_summary(data, column), use_container_width=True, hide_index=True)
            left, right = st.columns(2)
            with left:
                st.plotly_chart(px.histogram(data, x=column, nbins=30, title=f"Distribución de {column}"), use_container_width=True)
            with right:
                st.plotly_chart(px.box(data, y=column, title=f"Valores atípicos de {column}"), use_container_width=True)
    with relations_tab:
        correlation = correlation_matrix(data)
        if correlation.empty:
            st.info("Se necesitan al menos dos columnas numéricas para correlaciones.")
        else:
            st.plotly_chart(px.imshow(correlation, text_auto=".2f", title="Correlación entre variables numéricas"), use_container_width=True)
            x_column = st.selectbox("Eje X", numeric_columns, key="scatter_x")
            y_column = st.selectbox("Eje Y", numeric_columns, index=min(1, len(numeric_columns) - 1), key="scatter_y")
            st.plotly_chart(px.scatter(data, x=x_column, y=y_column, title=f"{y_column} frente a {x_column}"), use_container_width=True)
        valid_groups = [column for column in categorical_columns if data[column].nunique(dropna=True) == 2]
        if numeric_columns and valid_groups:
            try:
                test = group_difference(data, numeric_columns[0], valid_groups[0])
                st.caption(
                    f"Contraste Mann-Whitney de {numeric_columns[0]} entre {test['grupo_1']} y {test['grupo_2']}: "
                    f"p={test['p_valor']:.4f}, efecto rank-biserial={test['tamano_efecto_rank_biserial']:.3f}."
                )
            except ValueError as error:
                st.info(str(error))
    with time_tab:
        possible_dates = [column for column in data.columns if "date" in column.lower() or "fecha" in column.lower()]
        if not possible_dates or not numeric_columns:
            st.info("Se necesita una columna de fecha y una variable numérica para el análisis temporal.")
        else:
            date_column = st.selectbox("Fecha", possible_dates, key="time_date")
            value_column = st.selectbox("Variable temporal", numeric_columns, key="time_value")
            series, warnings = temporal_summary(data, date_column, value_column)
            for warning in warnings:
                st.warning(warning.message)
            st.plotly_chart(
                px.line(series, x=date_column, y=value_column, color="anomaly", title="Evolución temporal y anomalías"),
                use_container_width=True,
            )
            if len(series) >= 40:
                middle = len(series) // 2
                try:
                    psi = population_stability_index(series[value_column].iloc[:middle], series[value_column].iloc[middle:])
                    st.metric("Deriva de distribución (PSI)", f"{psi:.3f}")
                    st.caption("PSI cercano a 0 indica distribuciones similares; valores altos sugieren revisar cambios de datos o negocio.")
                except ValueError as error:
                    st.info(str(error))
    with robustness_tab:
        if not numeric_columns:
            st.info("Se necesita una variable numérica para bootstrap y segmentación.")
            return
        bootstrap_column = st.selectbox("Variable para bootstrap", numeric_columns, key="bootstrap_column")
        try:
            mean, lower, upper = bootstrap_mean_interval(data[bootstrap_column])
            st.metric("Media observada", f"{mean:,.3f}")
            st.caption(f"Intervalo bootstrap del 95 %: [{lower:,.3f}, {upper:,.3f}].")
        except ValueError as error:
            st.warning(str(error))
        if len(numeric_columns) >= 2:
            cluster_columns = st.multiselect("Variables para segmentación", numeric_columns, default=numeric_columns[:2])
            clusters = st.slider("Número de segmentos", 2, 6, 3)
            if len(cluster_columns) >= 2 and st.button("Crear segmentos"):
                try:
                    segmented = data.copy()
                    segmented["segment"] = segment_rows(data, cluster_columns, clusters)
                    st.plotly_chart(
                        px.scatter(
                            segmented.dropna(subset=["segment"]),
                            x=cluster_columns[0],
                            y=cluster_columns[1],
                            color="segment",
                            title="Segmentación exploratoria",
                        ),
                        use_container_width=True,
                    )
                    st.caption("La segmentación describe grupos similares; no demuestra causalidad ni predice por sí sola.")
                except ValueError as error:
                    st.warning(str(error))

def render_inventory_profitability() -> None:
    """Render coverage and capital metrics if sales and inventory are available."""
    st.subheader("Inventario y rentabilidad")
    data = _business_data()
    sales, inventory = data.get(SALES_CONTRACT.key), data.get(INVENTORY_CONTRACT.key)
    if sales is None or inventory is None:
        st.info("Carga ventas e inventario para calcular cobertura, capital expuesto y riesgos.")
        return
    costs = data.get(COSTS_CONTRACT.key)
    if costs is not None:
        cost_columns = [column for column in ("product_id", "unit_cost", "unit_price") if column in costs]
        cost_reference = costs[cost_columns].drop_duplicates("product_id")
        inventory = inventory.merge(cost_reference, on="product_id", how="left", suffixes=("", "_costs"))
        for column in ("unit_cost", "unit_price"):
            cost_column = f"{column}_costs"
            if cost_column not in inventory:
                continue
            if column in inventory:
                inventory[column] = inventory[column].fillna(inventory[cost_column])
            else:
                inventory[column] = inventory[cost_column]
            inventory = inventory.drop(columns=cost_column)
    daily = sales.groupby("product_id", as_index=False)["quantity"].mean()
    intelligence = inventory_intelligence(inventory, daily)
    total_capital = intelligence["capital_exposed"].sum()
    first, second, third = st.columns(3)
    first.metric("Capital expuesto", f"{total_capital:,.2f} €")
    second.metric("Riesgo de rotura", int(intelligence["risk"].eq("rotura").sum()))
    third.metric("Riesgo de sobrestock", int(intelligence["risk"].eq("sobrestock").sum()))
    display_columns = ["product_id", "on_hand_units", "daily_demand", "coverage_days", "capital_exposed"]
    if "unit_margin" in intelligence:
        display_columns.append("unit_margin")
    display_columns.append("risk")
    st.dataframe(
        intelligence[display_columns].sort_values("capital_exposed", ascending=False),
        use_container_width=True,
        hide_index=True,
    )
    st.caption("La cobertura usa demanda diaria observada del archivo cargado; no es una previsión si no se activa el módulo de demanda.")


def render_lot_risk() -> None:
    """Render the specialised expiry-risk view only for companies that provide lot data."""
    st.markdown(
        """
        <style>
        .lot-dashboard-title {font-size: 1.6rem; font-weight: 700; color: #0f172a; margin-bottom: 0.15rem;}
        .lot-dashboard-subtitle {color: #64748b; margin-bottom: 1rem;}
        .lot-alert {background: #fff7ed; border: 1px solid #fed7aa; border-radius: 0.6rem;
                    padding: 1rem; color: #9a3412; margin: 1rem 0;}
        </style>
        """,
        unsafe_allow_html=True,
    )
    st.markdown('<div class="lot-dashboard-title">Centro de control de riesgos por lote</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="lot-dashboard-subtitle">Prioriza inventario con fecha límite según demanda, stock y coste de tu empresa.</div>',
        unsafe_allow_html=True,
    )
    st.subheader("Riesgo por lote")
    st.write(
        "Este módulo opcional prioriza lotes con fecha límite a partir de las ventas históricas de la empresa. "
        "No usa datos de demostración."
    )
    data = _business_data()
    sales, lots = data.get(SALES_CONTRACT.key), data.get(LOTS_CONTRACT.key)
    if sales is None or lots is None:
        st.info("Carga ventas.csv y lotes.csv para habilitar el riesgo por lote.")
        return
    risks, warnings = build_lot_risk(lots, sales)
    for warning in warnings:
        st.warning(warning)
    if risks.empty:
        return
    valid_risks = risks.dropna(subset=["risk_probability"]).copy()
    if valid_risks.empty:
        st.info("Ningún lote tiene todavía suficiente historial de ventas para estimar su riesgo.")
        return
    critical_lots = valid_risks.loc[valid_risks["risk_probability"] >= 0.60]
    first, second, third, fourth = st.columns(4)
    first.metric("Coste expuesto estimado", f"{valid_risks['cost_exposed'].sum():,.2f} €")
    second.metric("Lotes prioritarios", len(critical_lots))
    third.metric("Riesgo medio", f"{valid_risks['risk_probability'].mean():.1%}")
    fourth.metric("Stock analizado", f"{valid_risks['stock_available'].sum():,.0f} ud")
    if not critical_lots.empty:
        top_lot = critical_lots.sort_values("cost_exposed", ascending=False).iloc[0]
        st.markdown(
            (
                '<div class="lot-alert"><strong>Acción prioritaria:</strong> '
                f'Lote {top_lot["lot_id"]} · {top_lot["product_id"]} · '
                f'coste expuesto estimado de {top_lot["cost_exposed"]:,.2f} € · '
                f'{top_lot["recommendation"]}.</div>'
            ),
            unsafe_allow_html=True,
        )
    else:
        st.success("No hay lotes con riesgo alto según el historial y los datos cargados.")
    ranked_lots = valid_risks.copy()
    ranked_lots["risk_level"] = pd.cut(
        ranked_lots["risk_probability"],
        bins=[-0.01, 0.30, 0.60, 0.85, 1.0],
        labels=["Bajo", "Medio", "Alto", "Crítico"],
    )
    display_columns = [
        "lot_id",
        "product_id",
        "stock_available",
        "expiry_date",
        "days_remaining",
        "daily_demand",
        "risk_probability",
        "risk_level",
        "cost_exposed",
        "recommendation",
    ]
    st.dataframe(
        ranked_lots[display_columns]
        .sort_values("cost_exposed", ascending=False)
        .style.format({"risk_probability": "{:.1%}", "cost_exposed": "{:,.2f} €", "daily_demand": "{:,.2f}"}),
        use_container_width=True,
        hide_index=True,
    )
    selected_lot = st.selectbox("Ver detalle de un lote", valid_risks["lot_id"].astype(str).tolist())
    selected = valid_risks.loc[valid_risks["lot_id"].astype(str) == selected_lot].iloc[0]
    detail_left, detail_right = st.columns(2)
    with detail_left:
        st.markdown("#### Explicación del riesgo")
        st.write(
            f"Con una demanda diaria observada de **{selected['daily_demand']:.2f} unidades**, "
            f"se estiman **{selected['expected_sales_before_expiry']:.2f} unidades** vendidas antes "
            f"de la fecha límite. El lote tiene {selected['stock_available']:.2f} unidades disponibles."
        )
    with detail_right:
        st.markdown("#### Acción recomendada")
        st.success(selected["recommendation"])
        st.write(
            f"Riesgo estimado: **{selected['risk_probability']:.1%}**. "
            f"Coste expuesto estimado: **{selected['cost_exposed']:,.2f} €**."
        )
    st.caption(
        "Riesgo estimado = unidades que previsiblemente no se venderán antes de la fecha límite / stock del lote. "
        "Es una estimación basada en el historial cargado, no una merma confirmada."
    )


def render_scenarios() -> None:
    """Expose scenario calculations with explicit assumptions and no claims of realised savings."""
    st.subheader("Simulador económico")
    st.write("Compara un escenario con su línea base. Los resultados son estimaciones, no ahorros realizados.")
    left, middle, right = st.columns(3)
    with left:
        units = st.number_input("Unidades base", min_value=1.0, value=100.0)
        price = st.number_input("Precio unitario base (€)", min_value=0.01, value=10.0)
        cost = st.number_input("Coste unitario (€)", min_value=0.0, value=5.0)
    with middle:
        holding = st.number_input("Coste de almacenamiento (€/ud/día)", min_value=0.0, value=0.05)
        days = st.number_input("Días de almacenamiento", min_value=0.0, value=7.0)
    with right:
        price_change = st.slider("Cambio de precio (%)", -80, 50, -10)
        demand_change = st.slider("Cambio supuesto en demanda (%)", -80, 200, 15)
    result = compare_scenario(units, price, cost, holding, days, price_change, demand_change)
    baseline = compare_scenario(units, price, cost, holding, days, 0, 0)
    first, second, third = st.columns(3)
    first.metric("Margen base estimado", f"{baseline.gross_margin:,.2f} €")
    second.metric("Margen de escenario", f"{result.gross_margin:,.2f} €")
    third.metric("Variación estimada", f"{result.margin_change:,.2f} €")
    st.caption(
        "Supuesto: el cambio de demanda indicado es una hipótesis del usuario. "
        "El sistema no afirma que el descuento vaya a producir ese efecto."
    )


def render_real_demand() -> None:
    """Show evaluated real-data demand evidence without claiming it represents the user's company."""
    st.subheader("Previsión de demanda con datos reales")
    st.write(
        "Esta demostración usa FreshRetailNet-50K, un conjunto real de ventas de perecederos. "
        "No representa la empresa del usuario ni contiene sus costes internos."
    )
    if not METRICS_PATH.exists() or not FORECAST_PATH.exists():
        st.warning("No hay artefactos de evaluación real disponibles. Ejecuta `python -m src.real_demand` después de descargar la fuente.")
        st.link_button("Fuente oficial FreshRetailNet-50K", SOURCE_URL)
        return
    metrics = json.loads(METRICS_PATH.read_text(encoding="utf-8"))
    first, second, third = st.columns(3)
    first.metric("Observaciones evaluadas", metrics["evaluation_rows"])
    second.metric("MAE", metrics["mae"])
    third.metric("RMSE", metrics["rmse"])
    st.caption(metrics["evaluation_method"])
    forecasts = pd.read_csv(FORECAST_PATH)
    sample_key = forecasts[["store_id", "product_id"]].iloc[0]
    sample = forecasts.loc[
        (forecasts["store_id"] == sample_key["store_id"])
        & (forecasts["product_id"] == sample_key["product_id"])
    ]
    st.plotly_chart(
        px.line(
            sample,
            x="dt",
            y=["sale_amount", "forecast_units"],
            title="Ventas reales y previsión de referencia para una serie real",
            labels={"value": "Unidades vendidas", "dt": "Fecha"},
        ),
        use_container_width=True,
    )
    st.link_button("Fuente y licencia CC BY 4.0", SOURCE_URL)
