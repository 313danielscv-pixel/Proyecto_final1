"""ResQData AI project package."""

