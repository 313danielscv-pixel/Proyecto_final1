"""ResQ Intelligence Streamlit application."""

from __future__ import annotations

import streamlit as st

from src.platform_ui import (
    render_advanced_eda,
    render_business_eda,
    render_inventory_profitability,
    render_lot_risk,
    render_real_demand,
    render_scenarios,
    render_uploads,
)


def main() -> None:
    """Render the reusable decision-intelligence platform."""
    st.set_page_config(page_title="ResQ Intelligence", page_icon="📈", layout="wide")
    st.title("ResQ Intelligence")
    st.caption("Inteligencia económica para decisiones de demanda, inventario y rentabilidad")

    with st.sidebar:
        st.header("Cómo funciona")
        st.write("1. Carga tus CSV.")
        st.write("2. Revisa la calidad y el análisis.")
        st.write("3. Evalúa inventario, lotes y escenarios.")
        st.info(
            "Los datos cargados solo se usan durante esta sesión. "
            "Las estimaciones no se presentan como ahorros realizados."
        )

    upload_tab, eda_tab, advanced_eda_tab, inventory_tab, lot_tab, scenario_tab, demand_tab, method_tab = st.tabs(
        [
            "Cargar datos empresa",
            "EDA empresarial",
            "EDA avanzado",
            "Inventario y margen",
            "Riesgo por lote",
            "Escenarios",
            "Demanda real",
            "Metodología",
        ]
    )
    with upload_tab:
        render_uploads()
    with eda_tab:
        render_business_eda()
    with advanced_eda_tab:
        render_advanced_eda()
    with inventory_tab:
        render_inventory_profitability()
    with lot_tab:
        render_lot_risk()
    with scenario_tab:
        render_scenarios()
    with demand_tab:
        render_real_demand()
    with method_tab:
        st.subheader("Método y límites")
        st.markdown(
            """
            - **Datos de empresa:** la plataforma valida archivos antes de activar cada módulo.
            - **Demanda real:** FreshRetailNet-50K se usa como demostración metodológica con fuente y licencia visibles.
            - **Riesgo por lote:** requiere historial de ventas y un CSV opcional de lotes con fecha límite.
            - **Escenarios:** comparan supuestos declarados por el usuario; no garantizan resultados.
            """
        )


if __name__ == "__main__":
    main()
