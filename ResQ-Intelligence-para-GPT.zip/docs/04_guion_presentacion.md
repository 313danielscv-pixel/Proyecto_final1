# Guion de exposición — ResQ Intelligence (15 minutos)

Usa diez diapositivas y una demo independiente. El texto entre comillas es una guía para explicar el proyecto con tus palabras.

| Parte | Tiempo |
|---|---:|
| Diapositivas 1 a 7 | 7 minutos |
| Demo de la aplicación | 3 minutos y 30 segundos |
| Diapositivas 8 a 10 | 4 minutos y 30 segundos |

## Diapositiva 1 de 10 — Problema y propuesta

**Título:** `ResQ Intelligence: decisiones para proteger el margen`

**Muestra:** demanda, inventario y rentabilidad como tres áreas conectadas.

> “ResQ Intelligence es una plataforma B2B que convierte datos operativos en decisiones económicas explicables. Una empresa no pierde margen por una sola causa: la demanda cambia, el inventario se desequilibra y los costes afectan a cada decisión.”

> “La pregunta que responde el proyecto es: ¿qué decisiones debe priorizar una empresa para proteger su margen a partir de su demanda, inventario y costes?”

## Diapositiva 2 de 10 — Usuario y recorrido

**Título:** `De CSV dispersos a una decisión priorizada`

**Muestra:** flujo: cargar CSV → validar → analizar → prever → comparar escenarios.

> “El usuario puede ser un responsable de operaciones, compras o finanzas. Carga los datos que tiene: ventas, inventario, costes y, si existen, proveedores.”

> “La plataforma valida la información antes de calcular nada. Después muestra evidencia, riesgos y escenarios. No exige que todas las empresas tengan exactamente los mismos campos.”

## Diapositiva 3 de 10 — Contratos de datos

**Título:** `Un núcleo reutilizable, no una plantilla rígida`

**Muestra:** tabla con `ventas.csv`, `inventario.csv`, `costes.csv` y `proveedores.csv`.

> “Definí contratos de datos con campos mínimos por módulo. Para demanda se necesita fecha, producto y cantidad. Para inventario, fecha, producto y stock. Para rentabilidad, producto, coste y precio.”

> “La fecha de caducidad es opcional. Si existe, activa el caso de perecederos; si no existe, la plataforma sigue funcionando para otros sectores.”

## Diapositiva 4 de 10 — Calidad de datos

**Título:** `No hay recomendaciones sin datos fiables`

**Muestra:** reglas de validación y ejemplos de mensajes claros.

> “La carga reconoce alias como fecha, SKU, producto, unidades o coste. Detecta campos ausentes, fechas inválidas, negativos, duplicados y valores nulos.”

> “Si no hay datos suficientes, el sistema no inventa una predicción. Explica qué módulo no puede activarse y qué campo falta.”

## Diapositiva 5 de 10 — Análisis exploratorio

**Título:** `Primero evidencias, después recomendaciones`

**Muestra:** pestaña EDA avanzado con perfil de datos, distribución, correlación y tendencia.

> “El análisis exploratorio comienza con un perfil de calidad: tipos, nulos, duplicados y advertencias. Después permite revisar distribuciones, valores atípicos, correlaciones, anomalías temporales y estabilidad de los datos.”

> “Los gráficos y las técnicas estadísticas solo aparecen si los datos cargados contienen la información y la muestra necesarias. Por ejemplo, la deriva necesita dos periodos comparables y la segmentación necesita al menos dos variables numéricas. El EDA descubre patrones e hipótesis; no prueba causalidad.”

## Diapositiva 6 de 10 — Datos reales y previsión de demanda

**Título:** `Demanda real con evaluación temporal`

**Muestra:** FreshRetailNet-50K, licencia CC BY 4.0, 4,5 millones de filas de entrenamiento y métricas.

> “Para demostrar previsión sobre datos reales uso FreshRetailNet-50K, un conjunto de ventas reales de productos perecederos con descuentos, promociones, clima y roturas de stock.”

> “La evaluación separa el tiempo: se entrena con información anterior y se evalúa con siete días posteriores. En un subconjunto reproducible de cien series, la referencia temporal obtiene MAE 0,5109 y RMSE 0,8352.”

> “Estos datos demuestran previsión de demanda. No afirmo que contengan costes internos, caducidades o mermas de la empresa usuaria.”

## Diapositiva 7 de 10 — Inventario y rentabilidad

**Título:** `De la demanda al riesgo económico`

**Muestra:** fórmula de cobertura, capital expuesto, rotura y sobrestock.

> “La plataforma cruza el inventario con la demanda observada. Calcula días de cobertura, riesgo de rotura si el stock no cubre el plazo de reposición y sobrestock si hay cobertura excesiva.”

> “El capital expuesto es stock por coste unitario. No es una pérdida realizada; muestra dónde hay más dinero inmovilizado y dónde conviene analizar una decisión.”

# Demo independiente — 3 minutos y 30 segundos

## Paso 1 — Cargar datos empresa

Abre **Cargar datos empresa** y sube las plantillas de `data/templates/`.

> “La empresa puede subir archivos independientes. El sistema detecta el mapeo de columnas y comunica cuántas filas son aptas, inválidas o duplicadas.”

## Paso 2 — EDA empresarial

Abre **EDA empresarial**.

> “Aquí veo la demanda diaria, los productos de mayor volumen y, si existe precio, la facturación. La plataforma no muestra métricas que sus datos no puedan respaldar.”

## Paso 3 — Inventario y margen

Abre **Inventario y margen**.

> “Esta vista ordena los productos por capital expuesto y clasifica riesgo de rotura, sobrestock o equilibrio.”

## Paso 4 — Escenarios

Abre **Escenarios**.

> “Ahora comparo un escenario base con un cambio de precio o demanda. El cambio de demanda es una hipótesis declarada por el usuario y el resultado se etiqueta como estimación.”

## Paso 5 — Demanda real y FreshMarket

Abre **Demanda real** y después **Predicción por lote**.

> “La pestaña de demanda real demuestra evaluación con una fuente externa real. FreshMarket se conserva como un caso especializado de alimentación, claramente identificado como piloto sintético.”

## Diapositiva 8 de 10 — Simulador económico

**Título:** `Comparar decisiones sin prometer ahorros`

**Muestra:** escenario base frente a descuento, reposición o cambio de coste.

> “La plataforma compara ingreso, coste de producto, coste de almacenamiento y margen estimado. El usuario ve todos los supuestos y puede modificar el escenario.”

> “No se presenta ninguna variación como ahorro conseguido. Es un cálculo de escenario que debe validarse con la operación real.”

## Diapositiva 9 de 10 — Caso FreshMarket

**Título:** `Un vertical especializado para perecederos`

**Muestra:** riesgo por lote, caducidad, descuento, donación y EDA de merma.

> “Conservo FreshMarket para mostrar cómo el núcleo general se especializa cuando hay datos de lote y caducidad.”

> “En ese caso se priorizan lotes por riesgo de merma y coste expuesto. Es una demostración sintética y no la fuente de los resultados de demanda real.”

## Diapositiva 10 de 10 — Límites y siguiente paso

**Título:** `Implementar con datos propios y medir impacto`

**Muestra:** cuatro pasos: cargar, validar, piloto, medir.

> “El siguiente paso para una empresa es cargar su histórico real, validar la calidad, evaluar su propio modelo de demanda y ejecutar un piloto controlado.”

> “Se deben medir margen, stock, roturas, sobrestock y resultado de las decisiones antes de automatizar acciones.”

> “En conclusión, ResQ Intelligence no sustituye el criterio empresarial: hace visibles los riesgos, explica los cálculos y permite comparar decisiones de forma responsable.”

## Preguntas previsibles

**¿Por qué no predice siempre la demanda?**  
> “Porque sin suficiente histórico sería una predicción inventada. Con menos de treinta observaciones, la plataforma se limita a análisis descriptivo.”

**¿Las estimaciones son ahorros reales?**  
> “No. Son comparaciones de escenarios basadas en supuestos visibles. El ahorro solo existe si se mide en la operación real.”

**¿Por qué usar datos reales de otra empresa?**  
> “Se usan para demostrar metodología de previsión con una fuente abierta y documentada. Cada cliente necesita evaluar su propio histórico antes de usar el modelo.”
